package br.com.senai.meuslivros.helper;

import android.widget.EditText;
import android.widget.ImageView;

import br.com.senai.meuslivros.FormularioActivity;
import br.com.senai.meuslivros.R;
import br.com.senai.meuslivros.model.Livro;

/**
 * Created by adminLocal on 11/04/2018.
 */

public class FormularioHelper {
    private ImageView capaDoLivro;
    private EditText tituloDoLivro;
    private EditText autorDoLivro;
    private Livro livro;

    public FormularioHelper(FormularioActivity formulario) {
        capaDoLivro = formulario.findViewById(R.id.imgLivro);
        tituloDoLivro = formulario.findViewById(R.id.editTitulo);
        autorDoLivro = formulario.findViewById(R.id.editAutor);

        livro = new Livro();
    }
}
